
# VERSÃO FINAL ESTILO "FUNÇÃO" (SEM O PROBLEMA DA PORTA)

import os
import random
import gspread
import json
from datetime import datetime
from flask import jsonify

# --- Configuração do Google Sheets ---
# COLE O CONTEÚDO DO SEU ARQUIVO credentials.json AQUI DENTRO DAS ASPAS TRIPLAS
google_credentials_str = """
{
  "type": "service_account",
  "project_id": "stately-arc-473123-c9",
  "private_key_id": "5416c7308a5215b9e96f524874b32fe71099fce2",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDFLTH3s8PVL8Ul\nndSfeXjR42FXprXkGrkCoIRs7oR2svF5yKs3JJEfaWdew9VghWIhosRSQKC3qKV/\nqi2+jf/SGFt6wmk4AlpRN94V4pbJaLPQM1KBUDkosOQ2ni9EppmIzVO/RgHTeAME\na/h9ks7Im/n3qEYE9Vlz1xMkNBA2sVGzKWhodSp0FTir1Auvz8kA8+fL6eZfWF3F\nZqGGj5PYjpyVH8Qi7vPsDb1SN+t82EhwzO25soOWZObh0+F5KGAUIi2ZzZ3KvFET\nmprM1XIL3VZqVsLn/UrbF+64sd+R/fi5dkCckwp+cGRW04XweRUa0pY5N/OmJ7Uz\nKm7+PJcTAgMBAAECggEAFRZlTqmCGy21tvUvRTL3kfLweTBSKagV+0rxfrjvn8Y5\nfx3P+eDGSIa8UG0/R8hcG17OAkH5LksyD/pCVCvZnT2PowxhtmTCBgekj9Cg8b9p\n461peHz87/YjIhg+0+fBadkTyNQS4+vk3rcxZzSpOtk7nZn4ixU2UOZCnM+YoFCc\nOFl3ClzPOxUIognKPhmJrFps0FkC/nt7s0gfFee1UvJ0CwGj/s7MCL8GrWrnsYg6\nRkywCIhyIbL8eSoCVg0aHCm3HjOn5tLdzOoipKyvxrYV1OLSFGjNm5ID1StdUxl5\nHdqtussGe9Ef7bf8YgnQDV575Nq5ipdxcu7dBXZOOQKBgQD20B5lq5CgaqPg6Zak\njc0q74FVkUQUHd93WRMQWcYtqAera7R4l+1dJze+dm9/8SpdGK+thxD/3v0qkZOk\nI3At7CL8vKhGJF/4B8uEFo+Mpr/hlLsvJODgTBMqLMvXUC+CPLSNwptaYjZdCrAa\n1so0ZE3sj50ycibREfMSnge79QKBgQDMhBdEx8hSFdn1lA623qrIzkaEP58WnIv+\n5zOFjyeWYL9faZFRJsEOVIVe3XpvsYWHwl2FjLgiqmXwibkLVKTxD1llY5nHUvvd\nKcLn26l7WZQRanUnmtQrk6vHiOV3YlIW0VrTDH1k1s7Wpw0GcCEffewXJog46zX1\nryzqoHDp5wKBgDG/vYDM1jgfhqzdKKo+ku5mnHE8+LX9V3/dCoSvM80cI3+gFB6C\nsSunrgrMIKlvWRSu1yppIToSHoGoGlRpeEEpadv7wwdwaY+7MoCLc5/sNJ0pt5lH\nG7TaYLqNkQDzfsAHsHUqltnfFgonD1w5k0SAO1zFjfAPJlfaAF7uT6zJAoGBAITx\nBFMgbrX1IFaDZME4otmfRLVoydgf8NzEm3ghI0GcKCo0bFLNF0diZ8PPwmvigINM\nNBDA9V0LWPJwBAo6fnF4YcsHYInyBmiwYdLnthbJlvdvNTKGcY7WEh7FfSwKjIPq\nmNiB0O0AuTlNI6lgsBdRemteD8S4GL5YnaDypBNXAoGAWoenJviyvO0s0BOPhJ2q\nrjF0HnBQSbuRWVsYXahYAdysww2Q69513V5rNMuiw76bL1yW3EzmsSr5WQg4tSK0\nR2y2oHbIzZWtVr66COnhDfAfRHZppXH8STVf9p0cM5+5eddy4IT2D1YU8k2F8583\nsTg1k3IgFuq990ou/KFWhtg=\n-----END PRIVATE KEY-----\n",
  "client_email": "webhook-sheets-editor@stately-arc-473123-c9.iam.gserviceaccount.com",
  "client_id": "113797708314319887552",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/webhook-sheets-editor%40stately-arc-473123-c9.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}
"""
google_credentials_dict = json.loads(google_credentials_str)

try:
    gc = gspread.service_account_from_dict(google_credentials_dict)
    spreadsheet = gc.open("Denuncias_Chatbot")
    worksheet = spreadsheet.get_worksheet(0)
except Exception as e:
    print(f"Erro ao conectar com Google Sheets: {e}")
    worksheet = None
# ------------------------------------

LOJAS_DE_RISCO = ["loja do zé", "importados duvidosos", "xyz eletronicos"]

def webhook(req):
    if req and req.get_json():
        request_json = req.get_json(silent=True, force=True)
    else:
        # Se a requisição for vazia, retorna OK mas não faz nada.
        return "OK", 200

    try:
        intent_name = request_json['queryResult']['intent']['displayName']
        print(f"NOME DA INTENT RECEBIDA: '{intent_name}'")
        
        if intent_name == 'iniciar_denuncia':
            all_params_present = request_json['queryResult'].get('allRequiredParamsPresent', False)
            if all_params_present:
                return jsonify({
                    "followupEventInput": {
                        "name": "evt_confirmar_denuncia",
                        "languageCode": "pt-BR"
                    }
                })
            else:
                return jsonify({})

        elif intent_name == 'confirmar_envio - yes': 
            params = request_json['queryResult']['parameters']
            
            prioridade = "Normal"
            motivo_risco = params.get('motivo', '').lower()
            tem_nf = params.get('nf', '').lower()
            loja = params.get('loja', '').lower()

            if "vazamento" in motivo_risco and tem_nf == "não" and loja in LOJAS_DE_RISCO:
                prioridade = "Alta"

            protocolo = f"DEN-{random.randint(10000, 99999)}"
            
            if worksheet:
                nova_linha = [
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    protocolo,
                    prioridade,
                    params.get('produto'),
                    params.get('modelo'),
                    params.get('serie'),
                    params.get('canal'),
                    params.get('loja'),
                    params.get('data', {}).get('date_time', '').split('T')[0],
                    params.get('local_uf'),
                    params.get('local_mun'),
                    str(params.get('valor', {}).get('amount', 'N/A')),
                    params.get('nf'),
                    params.get('motivo')
                ]
                worksheet.append_row(nova_linha)
            else:
                # Adiciona um print no log se não conseguir conectar na planilha
                print("ERRO: 'worksheet' não está definido. Verifique a conexão/permissões da planilha.")

            resposta_texto = (f"Denúncia registrada com sucesso! ✅\n"
                              f"Seu número de protocolo é: {protocolo}.\n"
                              f"A prioridade foi definida como: {prioridade}.\n"
                              "Nossa equipe de análise entrará em contato se precisar de mais informações.")

            return jsonify({"fulfillmentText": resposta_texto})

    except Exception as e:
        print(f"ERRO CRÍTICO NO WEBHOOK: {e}")
        return jsonify({"fulfillmentText": "Ocorreu um erro crítico no meu sistema. Por favor, tente novamente."})

    return jsonify({})